import consumer from "./consumer"

// document.addEventListener('turbolinks:load', () => {
//   const elementController = document.querySelector('body')
//   const controllerName = elementController.getAttribute('data-controller-name')
//   const actionName = elementController.getAttribute('data-action-name')

//   if (controllerName == 'questions' && actionName == 'show') {
//     const questionId = +(document.querySelector('#question_content').getAttribute('data-channel-room'))
//     console.log('Activity check question id')

    consumer.subscriptions.create({channel: "ActivityChannel", question_id: 59 }, {
      connected() {
        console.log('Connected Activity Channel')
        this.perform("appear")
      },

      disconnected() {
        // Called when the subscription has been terminated by the server
      },

      received(data) {
        console.log(data)
        let elements = document.querySelectorAll(`.user-${data.user_id}-status`);
        window.elements = elements
        for (var i = 0; i < elements.length; i++) {
          if (data.status == 'online' ) {
            elements[i].classList.add('online')
          } else {
            elements[i].classList.remove('online')
          }
        }
      }
    })
//   }
// })
