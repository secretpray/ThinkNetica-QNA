class ActivityChannel < ApplicationCable::Channel
  def subscribed
    stream_from "activity_channel/#{params[:question_id]}"
  end

  def unsubscribed
    ActionCable.server.broadcast "activity_channel/#{params[:question_id]}", 
                                  user_id: current_user&.id,
                                  status: 'offline'
  end

  def appear
    ActionCable.server.broadcast "activity_channel/#{params[:question_id]}", 
                                  user_id: current_user&.id,
                                  status: 'online'
  end
end
